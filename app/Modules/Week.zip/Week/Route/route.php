<?php

Route::group(['middleware'=>['web'],'namespace'=>'App\Modules\Week\Controllers'],function(){
    //
});