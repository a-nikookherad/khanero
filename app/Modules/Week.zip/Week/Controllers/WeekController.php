<?php

namespace App\Modules\Week\Controllers;

use Illuminate\Http\Request;

class WeekController extends Controller
{
    //
}
